#! /bin/bash

# train the models
napistu-torch train gcn_baseline.yaml --out-dir 20251106_gcn_baseline
napistu-torch train graphconv_baseline.yaml --out-dir 20251106_graphconv_baseline
napistu-torch train gcn_edge_encoding.yaml --out-dir 20251106_gcn_edge_encoding
napistu-torch train graphconv_edge_encoding.yaml --out-dir 20251106_graphconv_edge_encoding
napistu-torch train sage_baseline.yaml --out-dir 20251106_sage_baseline

napistu-torch test 20251106_gcn_baseline
napistu-torch test 20251106_graphconv_baseline
napistu-torch test 20251106_gcn_edge_encoding
napistu-torch test 20251106_graphconv_edge_encoding
napistu-torch test 20251106_sage_baseline
